# Warning 2.0

an installable app for the Zendesk sidebar

# Starting it up in dev

In your command line navigate to the warning_v2 directory and then run

```
cd warning_v2
zat s -c settings.json
```
